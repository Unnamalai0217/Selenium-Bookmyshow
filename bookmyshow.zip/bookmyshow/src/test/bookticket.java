package test;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.Test;

import reusablelibrary.*;





public class bookticket 
{
	
	 WebDriver driver;
	@Test 
	
	public void getDriver() throws Exception
	{
		driver = driverConfig.initDriver("Chrome","https://in.bookmyshow.com");
		
		reusableMethod reusemethod=new reusableMethod(driver);

		reusemethod.selectCity("Coimbatore");
		
		reusemethod.booktckt("KG Cinemas: Coimbatore","09:45 PM");
		
	}

}

package reusablelibrary;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;

public class reusableMethod 
{
	
WebDriver driver;

public reusableMethod(WebDriver driver) throws Exception

{
	
	this.driver = driver;
			
	
}

	public void selectCity(String city)  throws Exception
	{
		driver.findElement(By.id("inp_RegionSearch_top")).sendKeys(city);
		Thread.sleep(2000);
		driver.findElement(By.id("inp_RegionSearch_top")).sendKeys(Keys.ENTER);
		Thread.sleep(5000);
		
		driver.findElement(By.id("wzrk-cancel")).click();

	}
	
	public void booktckt(String theatrename, String showtime) throws Exception
	{
		driver.findElement(By.xpath("//div[@class='inner-nav left-nav']/ul/li[1]"));
		driver.findElement(By.xpath("//div/h4[text()='Kaithi']")).click();
		Thread.sleep(4000);
		driver.findElement(By.xpath("//a[@class='showtimes btn _cuatro']")).click();
		Thread.sleep(4000);
	     driver.findElement(By.xpath("//div[@class='date-container ']/ul//li[5]")).click();
	     Thread.sleep(4000);
		driver.findElement(By.xpath("//li[@data-name='"+theatrename+"']//div/a[@data-date-time='"+showtime+"']")).click();
		Thread.sleep(4000);
		driver.findElement(By.id("btnPopupAccept")).click();
		Thread.sleep(4000);	    
	    driver.findElement(By.id("proceed-Qty")).click();
	    Thread.sleep(4000);
	    driver.findElement(By.id("B_3_14")).click();
	    Thread.sleep(10000);
		driver.close();
		
	    

	
	}
	
	
	

}

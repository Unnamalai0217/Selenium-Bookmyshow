package reusablelibrary;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class driverConfig
{
	
	static WebDriver driver;
	
	public static WebDriver initDriver(String browsername, String url) throws Exception
	{
		switch(browsername)
		{
		case"Chrome":
			System.setProperty("webdriver.chrome.driver","C:\\Users\\Sasi Kumar\\.eclipse\\chromedriver.exe");
			 driver = new ChromeDriver();
			 driver.get(url);
			 driver.manage().window().maximize();
			 Thread.sleep(2000);
			 
			break;
			 
			default:
				System.setProperty("webdriver.chrome.driver","C:\\Users\\Sasi Kumar\\.eclipse\\chromedriver.exe");
				 driver = new ChromeDriver();
				
		}
		
	return driver;

	}


}
